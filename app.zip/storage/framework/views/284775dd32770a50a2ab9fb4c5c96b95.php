<?php
    $title = 'Report an Ad - Buy and Sell online for free with Kahustle.com Classifieds Ads';
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>

    <main>
        <div class="contactArea section-padding2">

            <div class="container">
                <div class="row">
                    <div class="col-8 mx-auto">

                        
                        <div class="mt-20 mb-20">
                            <?php if(session()->has('success')): ?>
                                <div class="status_success">
                                    <h4><i class="las la-check-circle icon"></i> Success!</h4>
                                    <p><?php echo e(session()->get('success')); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(session()->has('error')): ?>
                                <div class="status_error">
                                    <h4><i class="las la-exclamation-circle icon"></i> Error!</h4>
                                    <p><?php echo e(session()->get('success')); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                        

                        <div class="contact-Wrapper">
                            <form class="row" method="POST" action="<?php echo e(route('report.form')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="col-lg-12">
                                    <div class="section-tittle mb-40">
                                        <h2 class="tittle p-0">Report an Ad</h2>
                                        <p>Report an ad for review</p>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="section-tittle mb-40">
                                        <h6 class="p-0"><?php echo e($listing->title); ?></h6>
                                        <p>By <?php echo e($listing->user->name); ?></p>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <input type="hidden" name="listing" value="<?php echo e($listing->slug); ?>">
                                    <label class="infoTitle" id="message">Message</label>
                                    <div class="input-form">
                                        <textarea required style="border: 1px solid #afafaf!important; color: black;" name="message" id="message"
                                            placeholder="Your message"></textarea>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="btn-wrapper mb-10">
                                        <button type="submit" class="cmn-btn4 w-100">Report</button>
                                    </div>
                                </div>

                            </form>

                        </div>
                    </div>

                </div>
            </div>
        </div>

    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Projects\Kahustle-tests\template\resources\views/report.blade.php ENDPATH**/ ?>