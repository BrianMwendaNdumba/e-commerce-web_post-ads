<?php
    $title = $category->title . ' - Buy and Sell online for free with Kahustle.com Classifieds Ads';
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>

    <main>

        <div class="mt-40 plr">
            <div class="container-fluid">
                <div class="row">

                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.list-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('list-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                    <div class="col-xxl-9 col-xl-9 col-lg-8 col-md-7">

                        <div class="gridView customTab-content customTab-content-1 active">

                            <div class="mb-20 category_title">
                                <h1>Top <span class="category_name"><?php echo e($category->title); ?></span> Ads
                                    <span class="category_count">(<?php echo e(count($category->listing)); ?> items)</span>
                                </h1>
                            </div>

                            <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3">

                                <?php $__empty_1 = true; $__currentLoopData = $category->listing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col">

                                        <div class="singleFeature mb-24">

                                            <div class="featureImg">
                                                <a href="<?php echo e(route('listing.show', ['slug' => $listing->slug])); ?>"><img
                                                        style="width: 255px; height:206px; object-fit: cover;"
                                                        src="<?php echo e($listing->getFirstMediaUrl('listings')); ?>"
                                                        alt="<?php echo e($listing->title); ?>"></a>
                                            </div>

                                            <div class="featureCaption">
                                                <h4><a href="<?php echo e(route('listing.show', ['slug' => $listing->slug])); ?>"
                                                        class="featureTittle"><?php echo e($listing->title); ?></a>
                                                </h4>
                                                <span class="featurePricing">Ksh
                                                    <?php echo e(number_format($listing->price)); ?></span>
                                                <?php if($listing->user->location): ?>
                                                    <p class="featureCap"><?php echo e($listing->user->location); ?> · <strong
                                                            class="subCap"><?php echo e($listing->updated_at->diffForHumans(['parts' => 1])); ?></strong>
                                                    </p>
                                                <?php else: ?>
                                                    <p class="featureCap"><strong
                                                            class="subCap"><?php echo e($listing->updated_at->diffForHumans(['parts' => 1])); ?></strong>
                                                    </p>
                                                <?php endif; ?>
                                                <div class="btn-wrapper">
                                                    <span class="latest_badge">Latest</span>
                                                    <span class="premium_badge">Trending</span>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="no_category_items category_title">
                                        <p>No Items Found in this category. Please try other categories</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>


                        <?php if(count($category->listing) >= 20): ?>
                            
                            <div class="row justify-content-center">
                                <div class="col-lg-12">
                                    <div class="pagination mt-60">
                                        <ul class="pagination-list">
                                            <li class=" wow fadeInRight" data-wow-delay="0.0s"><a href="#"
                                                    class="page-number"><i class="las la-angle-left"></i></a></li>
                                            <li><span class="page-number current">1</span></li>
                                            <li><a href="#" class="page-number">2</a></li>
                                            <li><a href="#" class="page-number">3</a></li>
                                            <li><a href="#" class="page-number">4</a></li>
                                            <li><a href="#" class="page-number">5</a></li>
                                            <li class=" wow fadeInLeft" data-wow-delay="0.0s"><a href="#"
                                                    class="page-number"><i class="las la-angle-right"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                        <?php endif; ?>


                    </div>
                </div>
            </div>
        </div>

    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Projects\Kahustle-tests\template\resources\views/category.blade.php ENDPATH**/ ?>