<?php
    $title = $listing->title . ' - Buy and Sell online for free with Kahustle.com Classifieds Ads';
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>

    <main>

        <div class="proDetails pt-40">

            <div class="container">

                
                <div class="row mb-40">
                    <div class="col-sm-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('ads')); ?>">ads</a></li>
                                <li class="breadcrumb-item"><a
                                        href="<?php echo e(route('listing.show', ['slug' => $listing->slug])); ?>"><?php echo e($listing->title); ?></a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
                

                <div class="row">
                    <div class="col-xl-7 col-lg-12">

                        
                        <div class="product-view-wrap" id="myTabContent">
                            <div class="shop-details-gallery-slider global-slick-init slider-inner-margin sliderArrow"
                                data-asnavfor=".shop-details-gallery-nav" data-infinite="true" data-arrows="true"
                                data-dots="false" data-slidestoshow="1" data-swipetoslide="false" data-fade="true"
                                data-autoplay="false" data-autoplayspeed="2500"
                                data-prevarrow="<div class=&quot;prev-icon&quot;><i class=&quot;las la-angle-left&quot;></i></div>"
                                data-nextarrow="<div class=&quot;next-icon&quot;><i class=&quot;las la-angle-right&quot;></i></div>"
                                data-responsive="[{&quot;breakpoint&quot;: 1800,&quot;settings&quot;: {&quot;slidesToShow&quot;: 1}},{&quot;breakpoint&quot;: 1600,&quot;settings&quot;: {&quot;slidesToShow&quot;: 1}},{&quot;breakpoint&quot;: 1400,&quot;settings&quot;: {&quot;slidesToShow&quot;: 1}},{&quot;breakpoint&quot;: 1200,&quot;settings&quot;: {&quot;slidesToShow&quot;: 1}},{&quot;breakpoint&quot;: 991,&quot;settings&quot;: {&quot;slidesToShow&quot;: 1}},{&quot;breakpoint&quot;: 768, &quot;settings&quot;: {&quot;slidesToShow&quot;: 1}},{&quot;breakpoint&quot;: 576, &quot;settings&quot;: {&quot;slidesToShow&quot;: 1}}]">

                                <?php $__currentLoopData = $listing->getMedia('listings'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-main-image">
                                        <a class="long-img">
                                            <img src="<?php echo e($image->getUrl()); ?>" class="img-fluid" alt="image">
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                            <div class="thumb-wrap">
                                <div class="shop-details-gallery-nav global-slick-init slider-inner-margin sliderArrow"
                                    data-asnavfor=".shop-details-gallery-slider" data-focusonselect="true"
                                    data-infinite="true" data-arrows="false" data-dots="false" data-slidestoshow="6"
                                    data-swipetoslide="true" data-autoplay="false" data-autoplayspeed="2500"
                                    data-prevarrow="<div class=&quot;prev-icon&quot;><i class=&quot;las la-angle-left&quot;></i></div>"
                                    data-nextarrow="<div class=&quot;next-icon&quot;><i class=&quot;las la-angle-right&quot;></i></div>"
                                    data-responsive="[{&quot;breakpoint&quot;: 1800,&quot;settings&quot;: {&quot;slidesToShow&quot;: 6}},{&quot;breakpoint&quot;: 1600,&quot;settings&quot;: {&quot;slidesToShow&quot;: 6}},{&quot;breakpoint&quot;: 1400,&quot;settings&quot;: {&quot;slidesToShow&quot;: 6}},{&quot;breakpoint&quot;: 1200,&quot;settings&quot;: {&quot;slidesToShow&quot;: 6}},{&quot;breakpoint&quot;: 991,&quot;settings&quot;: {&quot;slidesToShow&quot;: 6}},{&quot;breakpoint&quot;: 768, &quot;settings&quot;: {&quot;slidesToShow&quot;: 4}},{&quot;breakpoint&quot;: 576, &quot;settings&quot;: {&quot;slidesToShow&quot;: 4}}]">

                                    <?php $__currentLoopData = $listing->getMedia('listings'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="single-thumb">
                                            <a class="thumb-link" data-toggle="tab">
                                                <img src="<?php echo e($image->getUrl()); ?>" alt="thumb">
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </div>

                        

                        
                        <div class="proDescription">
                            <?php if(auth()->guard()->check()): ?>
                                <form action="<?php echo e(route('favourite.form')); ?>" method="POST"
                                    class="descriptionTop favouritesForm">
                                    <?php echo csrf_field(); ?>

                                    <?php
                                        $is_liked = $listing->favourite->where('user_id', auth()->user()->id)->contains('listing_id', $listing->id) ? true : false;
                                    ?>

                                    <h4><a class="detailsTittle"><?php echo e($listing->title); ?>

                                            <i id="fav_icon" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['lar la-heart icon fav_icon', 'liked' => $is_liked]) ?>"></i>
                                        </a>
                                    </h4>
                                    <input type="hidden" name="favourite" value="<?php echo e($listing->slug); ?>">
                                    <p style="margin-bottom: 0;" class="detailsCap">Posted on
                                        <?php echo e(date('jS M Y', strtotime($listing->created_at))); ?>

                                    </p>
                                    <?php if($listing->condition): ?>
                                        <p style="margin-bottom: 0;" class="detailsCap">Listed as
                                            <?php echo e($listing->condition); ?>

                                        </p>
                                    <?php endif; ?>
                                    <p style="margin-bottom: 20px;" class="detailsCap">Category:
                                        <?php echo e($categories->find($listing->category_id)->title); ?>

                                    </p>
                                    <span class="detailsPricing">Ksh <?php echo e(number_format($listing->price)); ?> <span
                                            style="font-size: 13px; color: #667085;">Negotiable</span></span>
                                    <div class="infoSingle">
                                        <ul class="listing">
                                            <li class="listItem"><i class="las la-user icon"></i>By
                                                <?php echo e($listing->user->name); ?>

                                            </li>
                                            <?php if($listing->user->location): ?>
                                                <li class="listItem"><i class="las la-map-marker-alt icon"></i>
                                                    <?php echo e($listing->user->location); ?>

                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </form>
                            <?php endif; ?>

                            <?php if(auth()->guard()->guest()): ?>
                                <div class="descriptionTop favouritesForm">

                                    <h4><a href="<?php echo e(route('register')); ?>" class="detailsTittle"><?php echo e($listing->title); ?>

                                            <i class="lar la-heart icon fav_icon"></i>
                                        </a>
                                    </h4>
                                    <p class="detailsCap">Posted on <?php echo e(date('jS M Y', strtotime($listing->created_at))); ?>

                                    </p>
                                    <span class="detailsPricing">Ksh <?php echo e($listing->price); ?></span>
                                    <div class="infoSingle">
                                        <ul class="listing">
                                            <li class="listItem"><i class="las la-user icon"></i><?php echo e($listing->user->name); ?>

                                            </li>
                                            <?php if($listing->user->location): ?>
                                                <li class="listItem"><i class="las la-map-marker-alt icon"></i>
                                                    <?php echo e($listing->user->location); ?>

                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    </form>
                                <?php endif; ?>

                                <div class="descriptionMid">
                                    <div>
                                        <?php echo e(Str::of($listing->description)->toHtmlString()); ?>

                                    </div>
                                </div>

                                <div class="descriptionFooter">
                                    <div class="reviews_wrapper mb-40">
                                        <h6 style="font-weight: 600;" class="p-0 mb-10">Reviews</h6>

                                        <?php $__empty_1 = true; $__currentLoopData = $reviews->take(-3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="section-tittle mb-20">
                                                <h6 style="font-size: 15px;" class="p-0"><?php echo e($review->message); ?></h6>
                                                <p style="font-size: 13px;">
                                                    <?php echo e($review->user->name); ?></p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <div class="section-tittle mb-10">
                                                <h6 style="font-size: 15px;" class="p-0">There are no reviews</h6>
                                                <p style="font-size: 13px;">Be the first one to write a review</p>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>

                                <div class="descriptionFooter">
                                    <div class="review_form_wrapper w-100 mb-40">
                                        <form method="POST" action="<?php echo e(route('review.form')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="listing" value="<?php echo e($listing->slug); ?>">

                                            <label class="infoTitle" id="message">Write a review</label>
                                            <textarea class="review_textarea" required style="border: 1px solid #afafaf!important; color: black;" name="message"
                                                id="message" placeholder="Your review"></textarea>
                                            <button type="submit"
                                                class="custom_button_one btn_size_medium trasition_medium">Submit</button>
                                        </form>
                                    </div>
                                </div>

                                <div class="descriptionFooter mt-80">
                                    <div class="btn-wrapper">
                                        <a href="<?php echo e(route('report', ['slug' => $listing->slug])); ?>"
                                            class="btn_danger">
                                            <i class="lab la-font-awesome-flag"></i>Report</a>
                                    </div>
                                    
                                </div>
                            </div>
                            
                        </div>

                        
                        <div class="col-xl-5 col-lg-12">

                            
                            <div class="sellerMessage mb-24">
                                <div class="singleFlexitem mb-24">

                                    <?php if($listing->user->getFirstMediaUrl('profile_image')): ?>
                                        <div class="recentImg">
                                            <img style="max-width:70px;"
                                                src="<?php echo e($listing->user->getFirstMediaUrl('profile_image')); ?>"
                                                alt="images">
                                        </div>
                                    <?php else: ?>
                                        <div class="recentImg">
                                            <img style="max-width:70px;"
                                                src="<?php echo e(asset('assets/img/gallery/avatar.jpg')); ?>" alt="images">
                                        </div>
                                    <?php endif; ?>

                                    <div class="recentCaption">
                                        <h5><a class="featureTittle"><?php echo e($listing->user->name); ?></a>
                                        </h5>
                                        <p class="featureCap">Member since
                                            <?php echo e(date('M Y', strtotime($listing->user->created_at))); ?></p>
                                    </div>
                                </div>
                                <form action="#" class="contactSeller">
                                    <div class="row">
                                        <div class="col-lg-8">
                                            <div class="input-form">
                                                <input type="text" class="fake_contact" placeholder="07 ********">
                                                <input type="text" class="real_contact"
                                                    placeholder="<?php echo e($listing->user->phone_number); ?>">

                                                <div class="icon"><i class="las la-phone"></i></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="btn-wrapper mb-20">
                                                <a class="btn_alt w-100 reveal_button">Reveal Contact</a>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <div class="btn-wrapper">
                                    <a href="tel:<?php echo e($listing->user->phone_number); ?>" class="btn_main w-100"><i
                                            class="las la-phone"></i>Call
                                        seller</a>
                                </div>
                            </div>
                            

                            
                            <section class="recentListing">
                                <?php $__currentLoopData = $listings->take(-5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="borderStyle style1 wow fadeInLeft social"
                                        data-wow-delay="0.<?php echo e($loop->iteration); ?>s">
                                        <div class="singleFlexitem mb-24">
                                            <div class="recentImg">
                                                <img style="width: 255px; height:206px; object-fit: cover;"
                                                    src="<?php echo e($listing->getFirstMediaUrl('listings')); ?>"
                                                    alt="images">
                                            </div>
                                            <div class="recentCaption">
                                                <h5><a href="<?php echo e(route('listing.show', ['slug' => $listing->slug])); ?>"
                                                        class="featureTittle"><?php echo e($listing->title); ?></a></h5>
                                                <?php if($listing->user->location): ?>
                                                    <p class="featureCap"><?php echo e($listing->user->location); ?> · <strong
                                                            class="subCap"><?php echo e($listing->updated_at->diffForHumans(['parts' => 1])); ?></strong>
                                                    </p>
                                                <?php else: ?>
                                                    <p class="featureCap">&nbsp; · <strong
                                                            class="subCap"><?php echo e($listing->updated_at->diffForHumans(['parts' => 1])); ?></strong>
                                                    </p>
                                                <?php endif; ?>
                                                <span class="featurePricing">Ksh
                                                    <?php echo e(number_format($listing->price)); ?></span>
                                                <div class="btn-wrapper">
                                                    <span class="latest_badge">Latest</span>
                                                    <span class="premium_badge">Trending</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </section>
                            

                        </div>
                        

                    </div>
                </div>
            </div>

    </main>

     <?php $__env->slot('scripts', null, []); ?> 
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/reveal.js']); ?>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Projects\Kahustle-tests\template\resources\views/ad.blade.php ENDPATH**/ ?>