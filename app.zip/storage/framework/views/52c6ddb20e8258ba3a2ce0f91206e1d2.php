<?php
    $myAds = $ads;
    $title = 'Your Account - Buy and Sell online for free with Kahustle.com Classifieds Ads';
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>

    <main>

        <div class="myAccout section-padding2 myaccount_section_padding">
            <div class="container">
                <div class="row">

                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                    <div class="col-xxl-9 col-xl-9 col-lg-8 col-md-7">

                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-breadcrumbs','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                        <div class="mt-20 mb-20">
                            <?php if(session()->has('success')): ?>
                                <div class="status_success">
                                    <h4><i class="las la-check-circle icon"></i> Success!</h4>
                                    <p><?php echo e(session()->get('success')); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(session()->has('error')): ?>
                                <div class="status_error">
                                    <h4><i class="las la-exclamation-circle icon"></i> Error!</h4>
                                    <p><?php echo e(session()->get('success')); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="accountWrapper mt-20 mb-24">

                            <div class="userProfile mb-24">

                                <?php if(Auth::user()->getFirstMediaUrl('profile_image')): ?>
                                    <div class="recentImg">
                                        <img style="max-width:70px;"
                                            src="<?php echo e(Auth::user()->getFirstMediaUrl('profile_image')); ?>"
                                            alt="user avatar">
                                    </div>
                                <?php else: ?>
                                    <div class="recentImg">
                                        <img style="max-width:70px;" src="/assets/img/gallery/avatar.jpg"
                                            alt="user avatar">
                                    </div>
                                <?php endif; ?>

                                <div class="recentCaption">
                                    <div class="cap">
                                        <h5><a href="#" class="featureTittle"><?php echo e(Auth::user()->name); ?></a></h5>
                                        <p class="featureCap">Member since
                                            <?php echo e(date('M Y', strtotime(Auth::user()->created_at))); ?>

                                        </p>
                                    </div>
                                    <div class="btn-wrapper">
                                        <a href="<?php echo e(route('dashboard.profile')); ?>"
                                            class="custom_button_one btn_size_medium trasition_medium">Edit
                                            Profile</a>
                                    </div>
                                </div>
                            </div>

                            <div class="infoSingle">
                                <ul class="listing">
                                    <li class="listItem"><i class="las la-map-marker-alt icon"></i>
                                        <?php if(Auth::user()->location): ?>
                                            <?php echo e(Auth::user()->location); ?>

                                        <?php else: ?>
                                            Location Not Set
                                        <?php endif; ?>
                                    </li>
                                    <li class="listItem"><i class="lar la-envelope-open icon"></i><a
                                            href="#"><?php echo e(Auth::user()->email); ?></a>
                                    </li>
                                    <li class="listItem"><i
                                            class="las la-phone icon"></i><?php echo e(Auth::user()->phone_number); ?></li>
                                </ul>
                            </div>
                        </div>

                        <div class="myListing">

                            <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="singleFlexitem mb-24 wow fadeInUp social">
                                    <div class="listCap">
                                        <div class="recentImg">
                                            <img style="width: 255px; height:206px; object-fit: cover;"
                                                src="<?php echo e($listing->getFirstMediaUrl('listings')); ?>" alt="images">
                                        </div>
                                        <div class="recentCaption">
                                            <h5><a href="<?php echo e(route('listing.show', ['slug' => $listing->slug])); ?>"
                                                    class="featureTittle"><?php echo e($listing['title']); ?></a>
                                            </h5>

                                            </p>
                                            <?php if($listing->user->location): ?>
                                                <p class="featureCap"><?php echo e($listing->user->location); ?> · <strong
                                                        class="subCap"><?php echo e($listing->updated_at->diffForHumans(['parts' => 1])); ?></strong>
                                                <?php else: ?>
                                                <p class="featureCap">Location Not Set · <strong
                                                        class="subCap"><?php echo e($listing->updated_at->diffForHumans(['parts' => 1])); ?></strong>
                                            <?php endif; ?>
                                            <span class="featurePricing">Ksh
                                                <?php echo e(number_format($listing['price'])); ?></span>
                                            <div class="btn-wrapper">
                                                <span class="latest_badge">Latest</span>
                                                <span class="premium_badge">Trending</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="btn-wrapper mb-20">
                                        <a href="<?php echo e(route('dashboard.edit', ['slug' => $listing->slug])); ?>"
                                            class="custom_button_one btn_size_medium trasition_medium"><i
                                                class="lar la-edit"></i> Edit</a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>

    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Projects\Kahustle-tests\template\resources\views/dashboard/index.blade.php ENDPATH**/ ?>