<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <main>

        
        <div class="sliderArea heroBlackStyle plr">
            <div class="slider-active">
                <div class="single-slider heroPadding2 d-flex align-items-center">
                    <div class="container-fluid ">
                        <div class="row justify-content-between align-items-center">
                            <div class="col-xxl-6 col-xl-7 col-lg-7 ">
                                <div class="heroCaption">
                                    <h1 class="tittle hero_title" data-animation="fadeInUp" data-delay="0.1s">Buy and
                                        sell
                                        anything <span class="lineBrack">you want</span> </h1>
                                    <p class="pera" data-animation="fadeInUp" data-delay="0.3s">Kenya's most loved and
                                        trusted Free classifieds ads website. Browse through thousands of items near
                                        you.</p>

                                    <div class="btn-wrapper">
                                        <a href="<?php echo e(route('dashboard.create')); ?>"
                                            class="cmn-btn2 mr-15 mb-10 wow fadeInLeft btn_type_1"
                                            data-wow-delay="0.3s">Post Free Ad</a>
                                        <a href="<?php echo e(route('ads')); ?>" class="cmn-btn3 mb-10 wow fadeInRight btn_type_2"
                                            data-wow-delay="0.3s">Browse
                                            Ads</a>
                                    </div>
                                </div>

                            </div>
                            <div class="col-xxl-5 col-xl-5 col-lg-5">
                                <div class="hero-man d-none d-lg-block">
                                    <img src="/assets/img/hero/hero-man3.png" alt="images" class="tilt-effect "
                                        data-animation="fadeInRight" data-delay="0.2s">

                                    <div class=" shapeHero shapeHero6" data-animation="fadeInRight" data-delay="0.8s">
                                        <img src="/assets/img/hero/heroShape6.png" alt="images" class="heartbeat">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        

        
        <section class="exploreCategories section-padding">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-8 col-lg-7 col-md-10 col-sm-10">
                        <div class="section-tittle text-center mb-50">
                            <h2 class="section_title">Categories</h2>
                        </div>
                    </div>
                </div>

                <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 ">

                    <div class="col">
                        <div class="singleCategories wow fadeInUp mb-24" data-wow-delay=".2s">
                            <a href="<?php echo e(route('category', ['slug' => 'freelance'])); ?>" class="catThumb">
                                <img src="/assets/img/gallery/explore8.jpg" alt="images">
                            </a>
                            <div class="catCaptions">
                                <h6> <a href="<?php echo e(route('category', ['slug' => 'freelance'])); ?>" class="tittle">
                                        Freelance Services </a> </h6>
                                <p class="pera">12,990 items</p>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="singleCategories wow fadeInRight mb-24" data-wow-delay=".3s">
                            <a href="<?php echo e(route('category', ['slug' => 'properties'])); ?>" class="catThumb">
                                <img src="/assets/img/gallery/cat_2.jpg" alt="images">
                            </a>
                            <div class="catCaptions">
                                <h6> <a href="<?php echo e(route('category', ['slug' => 'properties'])); ?>" class="tittle">
                                        Properties </a> </h6>
                                <p class="pera">12,990 items</p>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="singleCategories wow fadeInLeft mb-24" data-wow-delay=".2s">
                            <a href="<?php echo e(route('category', ['slug' => 'health-and-beauty'])); ?>" class="catThumb">
                                <img src="/assets/img/gallery/cat_8.jpg" alt="images">
                            </a>
                            <div class="catCaptions">
                                <h6> <a href="<?php echo e(route('category', ['slug' => 'health-and-beauty'])); ?>" class="tittle">
                                        Health And
                                        Beauty
                                    </a> </h6>
                                <p class="pera">12,990 items</p>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="singleCategories wow fadeInDown mb-24" data-wow-delay=".2s">
                            <a href="<?php echo e(route('category', ['slug' => 'vehicles'])); ?>" class="catThumb">
                                <img src="/assets/img/gallery/cat_1.jpg" alt="images">
                            </a>
                            <div class="catCaptions">
                                <h6> <a href="<?php echo e(route('category', ['slug' => 'vehicles'])); ?>" class="tittle">
                                        Vehicles </a> </h6>
                                <p class="pera">12,990 items</p>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="singleCategories wow fadeInRight mb-24" data-wow-delay=".2s">
                            <a href="<?php echo e(route('category', ['slug' => 'jobs'])); ?>" class="catThumb">
                                <img src="/assets/img/gallery/cat_9.jpg" alt="images">
                            </a>
                            <div class="catCaptions">
                                <h6> <a href="<?php echo e(route('category', ['slug' => 'jobs'])); ?>" class="tittle">
                                        Jobs </a> </h6>
                                <p class="pera">12,990 items</p>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="singleCategories wow fadeInRight mb-24" data-wow-delay=".2s">
                            <a href="<?php echo e(route('category', ['slug' => 'fashion'])); ?>" class="catThumb">
                                <img src="/assets/img/gallery/explore5.jpg" alt="images">
                            </a>
                            <div class="catCaptions">
                                <h6> <a href="<?php echo e(route('category', ['slug' => 'fashion'])); ?>" class="tittle"> Fashion
                                    </a> </h6>
                                <p class="pera">12,990 items</p>
                            </div>
                        </div>
                    </div>

                    

                    <div class="col">
                        <div class="singleCategories wow fadeInLeft mb-24" data-wow-delay=".3s">
                            <a href="<?php echo e(route('category', ['slug' => 'sports'])); ?>" class="catThumb">
                                <img src="/assets/img/gallery/cat_4.jpg" alt="images">
                            </a>
                            <div class="catCaptions">
                                <h6> <a href="<?php echo e(route('category', ['slug' => 'sports'])); ?>" class="tittle"> Sports
                                    </a> </h6>
                                <p class="pera">12,990 items</p>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="singleCategories wow fadeInLeft mb-24" data-wow-delay=".2s">
                            <a href="<?php echo e(route('category', ['slug' => 'gaming'])); ?>" class="catThumb">
                                <img src="/assets/img/gallery/cat_3.jpg" alt="images">
                            </a>
                            <div class="catCaptions">
                                <h6> <a href="<?php echo e(route('category', ['slug' => 'gaming'])); ?>" class="tittle">
                                        Gaming </a> </h6>
                                <p class="pera">12,990 items</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        

        
        <section class="featureListing bottom-padding2">

            <div class="container">

                <div class="row">
                    <div class="col-xl-8 col-lg-7 col-md-10 col-sm-10">
                        <div class="section-tittle mb-50">
                            <h2 class="section_title">Featured Ads</h2>
                        </div>
                    </div>
                </div>

                <div class="row">

                    <?php $__currentLoopData = $listings->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3">

                            <div class="singleFeature mb-24">

                                <div class="featureImg">
                                    <a href="<?php echo e(route('listing.show', ['slug' => $listing->slug])); ?>"><img
                                            style="max-width: 612px; height:280px; object-fit: cover;"
                                            src="<?php echo e($listing->getFirstMediaUrl('listings')); ?>"
                                            alt="<?php echo e($listing->title); ?>"></a>
                                </div>

                                <div class="featureCaption">
                                    <h4><a href="<?php echo e(route('listing.show', ['slug' => $listing->slug])); ?>"
                                            class="featureTittle"><?php echo e($listing->title); ?></a>
                                    </h4>
                                    <span class="featurePricing">Ksh <?php echo e(number_format($listing->price)); ?></span>
                                    <?php if($listing->user->location): ?>
                                        <p class="featureCap"><i class="las la-map-marker"></i>
                                            <?php echo e($listing->user->location); ?>

                                        </p>
                                    <?php else: ?>
                                        <p class="featureCap">
                                            &nbsp;
                                        </p>
                                    <?php endif; ?>
                                    <div class="btn-wrapper">
                                        <span class="latest_badge">Latest</span>
                                        <span class="premium_badge">Trending</span>
                                    </div>
                                </div>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

        </section>
        

        
        
        

        
        <section class="aboutArea section-padding sectionBg1">
            <div class="container position-relative">
                <div class="row justify-content-center">
                    <div class="col-xxl-6 col-xl-7 col-lg-6">
                        <div class="about-caption about-caption2 mb-15  text-center">
                            <div class="section-tittle section-tittle2 mb-55">
                                <h2 class="tittle wow fadeInUp" data-wow-delay="0.0s">Post your ad today and start
                                    making money</h2>
                                <p class="wow fadeInUp" data-wow-delay="0.2s">Posting your ad is easy and free. Simply
                                    create an account, write a description of what you're selling or looking for, add
                                    some photos, and hit submit. Your ad could be just what someone else is looking for
                                </p>
                            </div>
                            <div class="btn-wrapper">
                                <a href="<?php echo e(route('dashboard.index')); ?>" class="cmn-btn2 mr-15 mb-10 wow fadeInLeft"
                                    data-wow-delay="0.3s">Post Free Ad</a>
                                <a href="<?php echo e(route('ads')); ?>" class="cmn-btn3 mb-10 wow fadeInRight"
                                    data-wow-delay="0.3s">Browse
                                    Ads</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="aboutShape aboutShape1">
                    <img src="/assets/img/gallery/aboutShape11.png" alt="images" class="bouncingAnimation">
                </div>
                <div class="aboutShape aboutShape2">
                    <img src="/assets/img/gallery/aboutShape2.png" alt="images" class="bouncingAnimation">
                </div>
            </div>
        </section>
        

    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Projects\Kahustle-tests\template\resources\views/index.blade.php ENDPATH**/ ?>