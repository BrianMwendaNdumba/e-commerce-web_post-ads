<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>

        <?php if(Request::segment(2)): ?>
            <li class="breadcrumb-item text-capitalize"><a
                    href="<?php echo e(url('dashboard') . '/' . Request::segment(2)); ?>"><?php echo e(Request::segment(2)); ?></a></li>
        <?php endif; ?>
        
    </ol>
</nav>
<?php /**PATH C:\Projects\Kahustle-tests\template\resources\views/components/dashboard-breadcrumbs.blade.php ENDPATH**/ ?>