                    
                    <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-5">
                        <div class="cateSidebar">
                            <h5 class="catTittle2">Categories</h5>

                            <ul class="listing listScroll">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="listItem"><a href="<?php echo e(route('category', ['slug' => $category->slug])); ?>"
                                            class="items">
                                            <span>
                                                <?php echo e($category->title); ?> </span></span>
                                        </a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                            
                            
                            

                        </div>
                    </div>
                    
<?php /**PATH /home/kahustle/public_html/resources/views/components/list-sidebar.blade.php ENDPATH**/ ?>