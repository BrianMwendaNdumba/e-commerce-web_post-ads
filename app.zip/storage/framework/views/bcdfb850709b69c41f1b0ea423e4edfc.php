<?php echo e($slot); ?>

<?php /**PATH C:\Projects\Kahustle-tests\template\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>