<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => 'Kahustle', 'description' => 'Laravel', 'keywords' => 'classified']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => 'Kahustle', 'description' => 'Laravel', 'keywords' => 'classified']); ?>
<?php foreach (array_filter((['title' => 'Kahustle', 'description' => 'Laravel', 'keywords' => 'classified']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta name="keywords" content="<?php echo e($keywords); ?>" />
    <meta name="description" content="<?php echo e($description); ?>">

    <title><?php echo e($title); ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@700;800;900&display=swap" rel="stylesheet">

    <link rel="icon" type="image/x-icon" sizes="20x20" href="/assets/img/icon/favicon.png">
    <link rel="stylesheet" href="/assets/css/bootstrap.css">
    <link rel="stylesheet" href="/assets/css/plugin.css">
    <link rel="stylesheet" href="/assets/css/main-style.css?4">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/overrides.css']); ?>
</head>

<body>
    <span class="screen-darken"></span>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php echo e($slot); ?>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <script src="/assets/js/jquery-3.6.0.min.js"></script>
    <script src="/assets/js/popper.min.js"></script>
    <script src="/assets/js/bootstrap.js"></script>

    <script src="/assets/js/plugin.js"></script>

    <script src="/assets/js/main.js?2"></script>

    <script type="text/javascript">
        function darken_screen(yesno) {
            if (yesno == true) {
                document.querySelector('.screen-darken').classList.add('active');
            } else if (yesno == false) {
                document.querySelector('.screen-darken').classList.remove('active');
            }
        }

        function close_offcanvas() {
            darken_screen(false);
            document.querySelector('.mobile-offcanvas.show').classList.remove('show');
            document.body.classList.remove('offcanvas-active');
        }

        function show_offcanvas(offcanvas_id) {
            darken_screen(true);
            document.getElementById(offcanvas_id).classList.add('show');
            document.body.classList.add('offcanvas-active');
        }

        document.addEventListener("DOMContentLoaded", function() {
            document.querySelectorAll('[data-trigger]').forEach(function(everyelement) {

                let offcanvas_id = everyelement.getAttribute('data-trigger');

                everyelement.addEventListener('click', function(e) {
                    e.preventDefault();
                    show_offcanvas(offcanvas_id);

                });
            });

            document.querySelectorAll('.btn-close').forEach(function(everybutton) {

                everybutton.addEventListener('click', function(e) {
                    e.preventDefault();
                    close_offcanvas();
                });
            });

            document.querySelector('.screen-darken').addEventListener('click', function(event) {
                close_offcanvas();
            });

        });
        // DOMContentLoaded  end
    </script>
</body>

</html>
<?php /**PATH C:\Projects\Kahustle-tests\template\resources\views/layouts/guest.blade.php ENDPATH**/ ?>