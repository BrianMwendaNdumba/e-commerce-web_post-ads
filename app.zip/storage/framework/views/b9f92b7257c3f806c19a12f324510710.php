<?php
    $title = 'Featured Ads - Buy and Sell online for free with Kahustle.com Classifieds Ads';
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>

    <main>

        <div class="myAccout section-padding2 myaccount_section_padding">
            <div class="container">
                <div class="row">

                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                    <div class="col-xxl-9 col-xl-9 col-lg-8 col-md-7">

                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-breadcrumbs','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                        <div class="mt-20 mb-20">
                            <?php if(session()->has('success')): ?>
                                <div class="status_success">
                                    <h4><i class="las la-check-circle icon"></i> Success!</h4>
                                    <p><?php echo e(session()->get('success')); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(session()->has('error')): ?>
                                <div class="status_error">
                                    <h4><i class="las la-exclamation-circle icon"></i> Error!</h4>
                                    <p><?php echo e(session()->get('success')); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        

                        <section class="pricingCard mt-40">

                            <div class="container">

                                <div class="row justify-content-center">
                                    <div class="col-xl-8 col-lg-7 col-md-10 col-sm-10">
                                        <div class="section-tittle text-center mb-50">
                                            <h2 class="tittle  "><span class="shape"></span>Post and Promote Your
                                                Ads</h2>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">

                                    <div class="col-12">

                                        <div class="singlePrice custom_price_table mb-24 wow fadeInDown"
                                            data-wow-delay=".1s">
                                            <h4 class="priceTittle">Basic</h4>
                                            <ul class="listing">
                                                <li class="listItem"><i class="las la-check icon"></i>Post 5 ads</li>
                                            </ul>
                                            <span class="price">Kshs 2,500<span class="subTittle"> /Per
                                                    month</span></span>
                                            <div class="btn-wrapper">
                                                <a href="#"
                                                    class="custom_button_one btn_size_large trasition_medium">Get
                                                    Started</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">

                                        <div class="singlePrice custom_price_table mb-24 wow fadeInRight"
                                            data-wow-delay=".2s">
                                            <h4 class="priceTittle">Premium</h4>
                                            <ul class="listing">
                                                <li class="listItem"><i class="las la-check icon"></i>Post top banner
                                                    one ad</li>
                                            </ul>
                                            <span class="price">Kshs 800<span class="subTittle"> /Per
                                                    week</span></span>
                                            <div class="btn-wrapper">
                                                <a href="#"
                                                    class="custom_button_one btn_size_large trasition_medium">Get
                                                    Started</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </section>
                    </div>

                </div>
            </div>
        </div>

    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/kahustle/public_html/resources/views/dashboard/featured.blade.php ENDPATH**/ ?>