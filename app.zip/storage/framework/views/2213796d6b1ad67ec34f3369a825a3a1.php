<div class="col-xxl-3 col-xl-3 col-lg-4 col-md-5">

    <div class="accountSidebar d-none d-md-block">
        <ul class="listing listScroll">

            <li class="listItem">
                <a href="<?php echo e(route('dashboard.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['items', 'active' => request()->routeIs('dashboard.index')]) ?>"> <i
                        class="lar la-user-circle icon"></i>
                    My Account</a>
            </li>

            <li class="listItem">
                <a href="<?php echo e(route('dashboard.create')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['items', 'active' => request()->routeIs('dashboard.create')]) ?>"><i
                        class="las la-address-card icon"></i>
                    Post Free Ad</a>
            </li>

            <li class="listItem">
                <a href="<?php echo e(route('dashboard.featured')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'items',
                    'active' => request()->routeIs('dashboard.featured'),
                ]) ?>"><i class="las la-ad icon"></i>
                    Featured Ads</a>
            </li>

            <li class="listItem">
                <a href="<?php echo e(route('dashboard.favourites')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'items',
                    'active' => request()->routeIs('dashboard.favourites'),
                ]) ?>"> <i
                        class="lar la-heart icon"></i>
                    Favourites</a>
            </li>

            

            <li class="listItem">
                <a href="<?php echo e(route('dashboard.profile')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['items', 'active' => request()->routeIs('dashboard.profile')]) ?>"> <i
                        class="las la-user-cog icon"></i>
                    Profile</a>
            </li>

            <li class="listItem">
                <a href="<?php echo e(route('dashboard.security')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'items',
                    'active' => request()->routeIs('dashboard.security'),
                ]) ?>"> <i
                        class="las la-user-cog icon"></i>
                    Security</a>
            </li>

            <li class="listItem">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <a class="items" href="route('logout')"
                        onclick="event.preventDefault();
                                                    this.closest('form').submit();">
                        <i class="las la-sign-out-alt icon"></i> <?php echo e(__('Log Out')); ?>

                    </a>
                </form>
            </li>
        </ul>

    </div>

    <ul class="custom_resp_nav d-md-none nav nav-pills nav-fill ">

        <li class="nav-item">
            <a href="<?php echo e(route('dashboard.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'nav-link',
                'active' => request()->routeIs('dashboard.index'),
            ]) ?>"> <i
                    class="lar la-user-circle icon"></i>
                My Account</a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('dashboard.create')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'nav-link',
                'active' => request()->routeIs('dashboard.create'),
            ]) ?>"><i
                    class="las la-address-card icon"></i>
                Post Free Ad</a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('dashboard.featured')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'nav-link',
                'active' => request()->routeIs('dashboard.featured'),
            ]) ?>"><i class="las la-ad icon"></i>
                Featured Ads</a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('dashboard.favourites')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'nav-link',
                'active' => request()->routeIs('dashboard.favourites'),
            ]) ?>"> <i
                    class="lar la-heart icon"></i>
                Favourites</a>
        </li>

        

        <li class="nav-item">
            <a href="<?php echo e(route('dashboard.profile')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'nav-link',
                'active' => request()->routeIs('dashboard.profile'),
            ]) ?>"> <i
                    class="las la-user-cog icon"></i>
                Profile</a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('dashboard.security')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'nav-link',
                'active' => request()->routeIs('dashboard.security'),
            ]) ?>"> <i
                    class="las la-user-cog icon"></i>
                Security</a>
        </li>

        <li class="nav-item">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <a class="nav-link" href="route('logout')"
                    onclick="event.preventDefault();
                                                this.closest('form').submit();">
                    <i class="las la-sign-out-alt icon"></i> <?php echo e(__('Log Out')); ?>

                </a>
            </form>
        </li>

    </ul>

</div>
<?php /**PATH /home/kahustle/public_html/resources/views/components/dashboard-sidebar.blade.php ENDPATH**/ ?>