<?php
    $title = 'Reviews - Buy and Sell online for free with Kahustle.com Classifieds Ads';
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>

    <main>

        <div class="myAccout section-padding2 myaccount_section_padding">
            <div class="container">
                <div class="row">

                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                    <div class="col-xxl-9 col-xl-9 col-lg-8 col-md-7">

                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                <li class="breadcrumb-item"><a href="#">Properties</a></li>
                                <li class="breadcrumb-item"><a href="#">Post ad</a></li>
                            </ol>
                        </nav>

                        <div class="promoteAds">

                            <div class="singlePromoteAds mb-24  wow fadeInUp social" data-wow-delay="0.0s">
                                <div class="asadshhf">
                                    <div class="adsImg">
                                        <img src="/assets/img/gallery/wishlist1.jpg" alt="images">
                                    </div>
                                    <div class="adsCaption">
                                        <h5><a href="add_details.html" class="adsTittle">A pair of sneakers for sell</a>
                                        </h5>
                                        <p class="adsPera">Dallas, Texas · <strong class="subCap">24hrs ago</strong></p>
                                        <span class="adsPricing">$330.80</span>
                                    </div>
                                </div>
                                <div class="btn-wrapper mb-20">
                                    <a href="wish_list.html" class="cmn-btn-outline5"><i
                                            class="las la-heart icon"></i>Favourite</a>
                                </div>
                            </div>

                            <div class="singlePromoteAds mb-24  wow fadeInUp social" data-wow-delay="0.2s">
                                <div class="asadshhf">
                                    <div class="adsImg">
                                        <img src="/assets/img/gallery/wishlist2.jpg" alt="images">
                                    </div>
                                    <div class="adsCaption">
                                        <h5><a href="add_details.html" class="adsTittle">Luxury couple apartment</a>
                                        </h5>
                                        <p class="adsPera">Dallas, Texas · <strong class="subCap">24hrs ago</strong></p>
                                        <span class="adsPricing">$120.34</span>
                                    </div>
                                </div>
                                <div class="btn-wrapper mb-20">
                                    <a href="wish_list.html" class="cmn-btn-outline5"><i
                                            class="las la-heart icon"></i>Favourite</a>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Special title treatment</h5>
                                    <p class="card-text">With supporting text below as a natural lead-in to additional
                                        content.</p>
                                    <a href="#" class="btn btn-primary">Go somewhere</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Projects\Kahustle-tests\template\resources\views/dashboard/reviews.blade.php ENDPATH**/ ?>