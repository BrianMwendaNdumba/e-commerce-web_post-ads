<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <main>

        <div class="featureListing section-padding2">
            <div class="container">

                <div class="row mb-40">
                    <div class="col-sm-12">
                        <div class="section-tittle">
                            <h2 class="section_title">Favourites</h2>
                        </div>
                    </div>
                </div>

                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5">

                    <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">

                            <div class="singleFeature mb-24">

                                <div class="featureImg">
                                    <a href="#"><img src="<?php echo e($ad['image_path']); ?>" alt="<?php echo e($ad['title']); ?>"></a>
                                </div>

                                <div class="featureCaption">
                                    <h4><a href="#" class="featureTittle"><?php echo e($ad['title']); ?></a>
                                    </h4>
                                    <span class="featurePricing">Ksh
                                        <?php echo e(number_format($ad['price'])); ?></span>
                                    <p class="featureCap"><i class="las la-map-marker"></i>
                                        <?php echo e($ad['location']); ?>

                                    </p>
                                    <div class="btn-wrapper">
                                        <?php if($ad['is_latest']): ?>
                                            <span class="latest_badge">Latest</span>
                                        <?php endif; ?>
                                        <?php if($ad['is_featured']): ?>
                                            <span class="premium_badge">Featured</span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row justify-content-center mt-40">
                    <div class="col-lg-12">
                        <div class="pagination">
                            <ul class="pagination-list">
                                <li class="wow fadeInRight" data-wow-delay="0.0s"><a href="#"
                                        class="page-number"><i class="las la-angle-left"></i></a></li>
                                <li><span class="page-number current">1</span></li>
                                <li><a href="#" class="page-number">2</a></li>
                                <li><a href="#" class="page-number">3</a></li>
                                <li><a href="#" class="page-number">4</a></li>
                                <li><a href="#" class="page-number">5</a></li>
                                <li class=" wow fadeInLeft" data-wow-delay="0.0s"><a href="#"
                                        class="page-number"><i class="las la-angle-right"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Projects\Kahustle-tests\template\resources\views/favorites.blade.php ENDPATH**/ ?>