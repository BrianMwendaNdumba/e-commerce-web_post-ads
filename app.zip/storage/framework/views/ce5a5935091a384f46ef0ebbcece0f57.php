<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <main>

        <div class="myAccout section-padding2 myaccount_section_padding">
            <div class="container">
                <div class="row">
                    <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-5">

                        <div class="accountSidebar">
                            <ul class="listing listScroll">
                                <li class="listItem">
                                    <a href="my_account.html" class="items active"> <i class="lar la-user-circle icon"></i>
                                        My Account</a>
                                </li>
                                <li class="listItem">
                                    <a href="memberShip.html" class="items"><i class="las la-address-card icon"></i>
                                        Membership</a>
                                </li>
                                <li class="listItem">
                                    <a href="promoted_add_list.html" class="items"><i class="las la-ad icon"></i>
                                        Promoted Ads</a>
                                </li>
                                <li class="listItem">
                                    <a href="wish_list.html" class="items"> <i class="lar la-heart icon"></i>
                                        Wishlist</a>
                                </li>
                                <li class="listItem">
                                    <a href="help.html" class="items"> <i class="lar la-question-circle icon"></i>
                                        Help</a>
                                </li>
                            </ul>
                            <div class="accessAccount">
                                <a href="#" class="account-btn"><i class="las la-sign-out-alt icon"></i>
                                    Logout</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-9 col-xl-9 col-lg-8 col-md-7">

                        <div class="row mb-24">
                            <div class="col-sm-12">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                        <li class="breadcrumb-item"><a href="#">My Account</a></li>
                                    </ol>
                                </nav>
                            </div>
                        </div>


                        <div class="accountWrapper mb-24">

                            <div class="userProfile mb-24">
                                <div class="recentImg">
                                    <img src="assets/img/gallery/myAccout.png" alt="images">
                                </div>
                                <div class="recentCaption">
                                    <div class="cap">
                                        <h5><a href="#" class="featureTittle">Cameron Williamson</a></h5>
                                        <p class="featureCap">Member since 2019</p>
                                    </div>
                                    <div class="btn-wrapper">
                                        <a href="#" class="cmn-btn-outline2">Edit Profile</a>
                                    </div>
                                </div>
                            </div>

                            <div class="infoSingle">
                                <ul class="listing">
                                    <li class="listItem"><i class="las la-map-marker-alt icon"></i>Ash Dr. San Jose,
                                        South Dakota</li>
                                    <li class="listItem"><i class="lar la-envelope-open icon"></i><a
                                            href="https://bytesed.com/cdn-cgi/l/email-protection" class="__cf_email__"
                                            data-cfemail="d5a6a0a5a5baa7a1958db2b0bbbcbaa0a6fbb6bab8">[email&#160;protected]</a>
                                    </li>
                                    <li class="listItem"><i class="las la-phone icon"></i>(480) 555-0103</li>
                                </ul>
                            </div>
                        </div>

                        <div class="myListing">

                            <div class="singleFlexitem mb-24  wow fadeInUp social" data-wow-delay="0.0s">
                                <div class="listCap">
                                    <div class="recentImg">
                                        <img src="assets/img/gallery/myList1.jpg" alt="images">
                                    </div>
                                    <div class="recentCaption">
                                        <h5><a href="add_details.html" class="featureTittle">Luxury couple apartment</a>
                                        </h5>
                                        <p class="featureCap">Dallas, Texas · <strong class="subCap">24hrs ago</strong>
                                        </p>
                                        <span class="featurePricing">$124.80</span>
                                        <div class="btn-wrapper">
                                            <span class="pro-btn1">RENOVETED</span>
                                            <span class="pro-btn2">PROMOTED</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="btn-wrapper mb-20">
                                    <a href="#" class="cmn-btn-outline4 mr-10"><i
                                            class="lar la-eye icon"></i>44k</a>
                                    <a href="#" class="cmn-btn4">Edit Ad</a>
                                </div>
                            </div>

                            <div class="singleFlexitem mb-24  wow fadeInUp social" data-wow-delay="0.1s">
                                <div class="listCap">
                                    <div class="recentImg">
                                        <img src="assets/img/gallery/myList2.jpg" alt="images">
                                    </div>
                                    <div class="recentCaption">
                                        <h5><a href="add_details.html" class="featureTittle">Beats Studio 3 Wireless
                                                Over Ear</a></h5>
                                        <p class="featureCap">Dallas, Texas · <strong class="subCap">24hrs
                                                ago</strong>
                                        </p>
                                        <span class="featurePricing">$124.80</span>
                                        <div class="btn-wrapper">
                                            <span class="pro-btn1">RENOVETED</span>
                                            <span class="pro-btn2">PROMOTED</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="btn-wrapper mb-20">
                                    <a href="#" class="cmn-btn-outline4 mr-10"><i
                                            class="lar la-eye icon"></i>44k</a>
                                    <a href="#" class="cmn-btn4">Edit Ad</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Projects\Kahustle-tests\template\resources\views/dashboard.blade.php ENDPATH**/ ?>